package org.example.model.database;

class PostgresDBConnectionDataHolder {
    public static final String URL = "jdbc:postgresql://localhost:5432/social_network";
    public static final String DRIVER = "org.postgresql.Driver";
    public static final String USERNAME = "postgres";
    public static final String PASSWORD = "postgres";

}
