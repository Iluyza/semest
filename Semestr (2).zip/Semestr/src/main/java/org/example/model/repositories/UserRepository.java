package org.example.model.repositories;

public class UserRepository {
}
