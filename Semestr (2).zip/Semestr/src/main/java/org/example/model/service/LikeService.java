package org.example.model.service;

public class LikeService {
}
